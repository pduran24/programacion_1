import java.util.Scanner;

public class Ejercicio_1 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        int[] numeros = new int[3];

        for (int i=0;i<3;i++){
            System.out.println("Introducir un numero: ");
            numeros[i] = sc.nextInt();
        }

        int mayor = numeros[0];

        for(int i=0;i<numeros.length;i++){
            if(numeros[i]>mayor){
                mayor = numeros[i];
            }
        }

        System.out.println("El mayor número es: "+mayor);

    }
}
