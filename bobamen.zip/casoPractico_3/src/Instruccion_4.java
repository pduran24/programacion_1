public class Instruccion_4 {

    public static void main(String[] args) {

        int suma=0;
        for(int i=50;i>=20;i-=2){
            suma+=i;
        }
        System.out.println(suma);
    }
}
